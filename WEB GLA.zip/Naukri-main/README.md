# Documantion 

Job Search Platform UI

Steps to run the Project : 

1- Extract .zip 

2- Run index.html 

3- View your File in favorite Browser 

Tested Browsers : 

1- Microsoft Edge (88.0.705.74) (Windows 10) (64 Bit) 

2- Google Chrome (88.0.4324.182) (Windows 10) (64 Bit) 

3- Mozilla Firefox (85.0.2) (Windows 10) (64 Bit) 

Screenshots : 

![Web capture_21-2-2021_213111_](https://user-images.githubusercontent.com/71846550/108636234-a5276d00-748c-11eb-8731-7b8b4bbd5c1f.jpeg)

![Web capture_21-2-2021_213027_](https://user-images.githubusercontent.com/71846550/108636238-a6f13080-748c-11eb-8eb0-8a0234e6f888.jpeg)
